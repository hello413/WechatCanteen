//app.js
App({
  globalData: {
    order_id: 1,
    time_id:'1'
  },
  onLoad: function () {

  },
  onLaunch: function () {

  }
})